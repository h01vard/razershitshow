#!/bin/bash
rmmod "razerkbd"
rmmod "razercontrol"
insmod "src/razercontrol.ko"

