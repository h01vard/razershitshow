---
name: Bug report
about: Something isn't right with the driver
title: "[BUG]"
labels: ''
assignees: UKSFM99

---

**Describe the bug**
A clear way of describing how the driver is misbehaving

**To Reproduce**
Steps to reproduce the behavior:

**Expected behavior**
What should the driver do?

**Optional but useful, packet capture from synapse**

If the driver is not doing as it should, it would be useful to provide a packet capture of you doing the same event in razer synapse. IE: increasing the fan RPM to 5000,
