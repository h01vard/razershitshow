# Useful notes
